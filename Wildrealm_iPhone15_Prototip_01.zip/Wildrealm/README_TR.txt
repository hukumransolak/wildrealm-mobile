WILDREALM: iPhone MMORPG Prototype 0.1

RUN ON IPHONE
1. Extract the ZIP on a computer.
2. Host the folder on any HTTPS static host (for example GitHub Pages, Netlify, or another static host).
3. Open the HTTPS page in Safari on your iPhone 15.
4. Tap MACERAYA BAŞLA.
5. Use the left joystick to move. Drag on the right side to rotate the camera. Attack and jump buttons are at bottom right.

IMPORTANT
- This is a first playable 3D client prototype, not yet a multiplayer game.
- It loads Three.js from jsDelivr, so internet access is required.
- The current version has placeholder stylized characters, local combat, and a simple quest.
- Next milestone: create a hosted authoritative multiplayer server, player synchronization, login, and persistent character data.
